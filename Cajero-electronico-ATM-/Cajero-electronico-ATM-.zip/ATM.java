public class ATM {
    String titular;
    double cantidad;

    public ATM() {
        String titular = "Daniel Quishpe";
        double cantidad;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }
}


